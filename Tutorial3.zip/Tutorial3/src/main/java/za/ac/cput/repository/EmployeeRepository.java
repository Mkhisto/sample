package za.ac.cput.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import za.ac.cput.domain.Employee;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByLastName(String lastName);
    List<Employee> findByLastNameAndSalary(String lastName, double salary);
    List<Employee> findBySalaryOrFirstname(double salary, String firstname);
    List<Employee> findBySalaryGreaterThan(double salary);
    List<Employee> findTop2ByLastNameOrderBySalaryDesc(String lastName);

}
