package za.ac.cput.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;


import java.util.Objects;

@Entity
public class Employee {

    @Id
    private Long employeeId;
    private String firstname;
    private String lastName;
    private double salary;

    private Employee(Builder builder) {

        this.employeeId = builder.employeeId;
        this.firstname = builder.firstname;
        this.lastName = builder.lastName;
        this.salary = builder.salary;

    }

    protected Employee() {

    }


    public Long getEmployeeId() {
        return employeeId;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastName() {
        return lastName;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", firstname='" + firstname + '\'' +
                ", lastName='" + lastName + '\'' +
                ", salary=" + salary +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return Double.compare(salary, employee.salary) == 0 && Objects.equals(employeeId, employee.employeeId) && Objects.equals(firstname, employee.firstname) && Objects.equals(lastName, employee.lastName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(employeeId, firstname, lastName, salary);
    }

    public static class Builder {

        private String firstname;
        private String lastName;
        private Long employeeId;
        private double salary;

        public Builder setFirstname(String firstname) {
            this.firstname = firstname;
            return this;
        }

        public Builder setLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder setEmployeeId(Long employeeId) {
            this.employeeId = employeeId;
            return this;
        }

        public Builder setSalary(double salary) {
            this.salary = salary;
            return this;
        }

        public Employee build() {
            return new Employee(this);
        }

        public Builder copy(Employee employee) {

            if(employee.getEmployeeId() != null){
                this.employeeId = employee.getEmployeeId();
            }

            this.employeeId = employee.employeeId;
            this.firstname = employee.firstname;
            this.lastName = employee.lastName;
            this.salary = employee.salary;
            return this;
        }

    }
}
