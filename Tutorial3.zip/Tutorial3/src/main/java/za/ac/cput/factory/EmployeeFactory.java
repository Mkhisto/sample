package za.ac.cput.factory;

import za.ac.cput.domain.Employee;
import za.ac.cput.util.Helper;

import static za.ac.cput.util.Helper.isValidSalary;

public class EmployeeFactory {

    public static Employee buildEmployee(Long employeeId, String firstname, String lastName, double salary){

        if (!Helper.isValidId(employeeId) ||
            Helper.isNullOrEmpty(firstname) ||
            Helper.isNullOrEmpty(lastName) ||
            !Helper.isValidSalary(salary)) {

            return null;
        }


        return new Employee.Builder()
                .setEmployeeId(employeeId)
                .setFirstname(firstname)
                .setLastName(lastName)
                .setSalary(salary)
                .build();
    }
}
