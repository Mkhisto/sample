package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Employee;
import za.ac.cput.repository.EmployeeRepository;

import java.util.List;

@Service
public class EmployeeService implements IEmployeeService {

    @Autowired
    private EmployeeRepository employeeRepo;

    @Override
    public Employee create(Employee obj) {
        return employeeRepo.save(obj);
    }

   @Override
    public Employee read(Long aLong) {
        return employeeRepo.findById(aLong).orElse(null);
    }

    @Override
    public Employee update(Employee obj) {
        return employeeRepo.save(obj);
    }

    @Override
    public boolean delete(Long aLong) {
        employeeRepo.deleteById(aLong);
        return employeeRepo.existsById(aLong);
    }

    @Override
    public List<Employee> getAll() {
        return employeeRepo.findAll();
    }


    public List<Employee> findEmployeeByLastName(String lastname) {
        return employeeRepo.findByLastName(lastname);
    }

    public List<Employee> findEmployeeByLastNameAndSalary(String lastname, double salary) {
        return employeeRepo.findByLastNameAndSalary(lastname, salary);
    }

    public List<Employee> findEmployeeBySalaryOrFirstname(double salary, String firstname) {
        return employeeRepo.findBySalaryOrFirstname(salary, firstname);
    }

    public List<Employee> findBySalaryGreaterThan(double salary) {
        return employeeRepo.findBySalaryGreaterThan(salary);
    }

    public List<Employee> findTop2ByLastNameOrderBySalaryDesc(String lastname) {
        return employeeRepo.findTop2ByLastNameOrderBySalaryDesc(lastname);
    }
}
