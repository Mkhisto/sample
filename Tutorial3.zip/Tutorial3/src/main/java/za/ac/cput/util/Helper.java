package za.ac.cput.util;

public class Helper {

    public static boolean isNullOrEmpty(String s) {
        if (s.isEmpty() || s == null)
            return true;
        return false;
    }

    public static boolean isValidId(Long id) {
        if (id != null && id > 0)
            return true;
        else
            return false;
    }

    public static boolean isValidSalary(double salary) {
        if (salary > 0)
            return true;
        else
            return false;
    }
}
