package za.ac.cput.service;

import org.springframework.stereotype.Service;

@Service
public interface IService <Object, ID>{

    Object create(Object obj);
    Object read(ID id);
    Object update(Object obj);
    boolean delete(ID id);


}
