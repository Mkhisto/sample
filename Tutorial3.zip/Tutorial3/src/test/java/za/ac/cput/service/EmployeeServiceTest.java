package za.ac.cput.service;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import za.ac.cput.domain.Employee;
import za.ac.cput.factory.EmployeeFactory;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EmployeeServiceTest {

    @Autowired
    EmployeeService employeeService;

    static Employee employee1;
    static Employee employee2;
    static Employee employee3;
    static Employee employee4;
    static Employee employee5;

    @BeforeAll
    static void setUp() {
        employee1 = EmployeeFactory.buildEmployee(45674L, "Pelisa", "Pali", 60000);
        employee2 = EmployeeFactory.buildEmployee(22334L, "Yvvonne", "Mthiyane", 60000);
        employee3 = EmployeeFactory.buildEmployee(29034L, "Alakhe", "Pali", 70000);
        employee4 = EmployeeFactory.buildEmployee(91374L, "Lindi", "Mthiyane", 50000);
        employee5 = EmployeeFactory.buildEmployee(67874L, "Junior", "Pali", 60000);
    }

    @Test
    @Order(1)
    void create() {
        Employee newEmployee = employeeService.create(employee1);
        assertNotNull(newEmployee);
        System.out.println(newEmployee);

        Employee newEmployee2 = employeeService.create(employee2);
        assertNotNull(newEmployee2);
        System.out.println(newEmployee2);

        Employee newEmployee3 = employeeService.create(employee3);
        assertNotNull(newEmployee3);
        System.out.println(newEmployee3);

        Employee newEmployee4 = employeeService.create(employee4);
        assertNotNull(newEmployee4);
        System.out.println(newEmployee4);

        Employee newEmployee5 = employeeService.create(employee5);
        assertNotNull(newEmployee5);
        System.out.println(newEmployee5);
    }



    @Test
    @Order(2)
    void read() {
        Employee foundEmployee = employeeService.read(employee1.getEmployeeId());
        assertNotNull(foundEmployee);
        System.out.println("Read: " + foundEmployee);
    }

    @Test
    @Order(3)
    void update() {
        Employee updatedReservation = new Employee.Builder().copy(employee1).setEmployeeId(65692L)
                .build();
        Employee result = employeeService.update(updatedReservation);

        assertNotNull(result);
        System.out.println("Updated: " + result);
    }

    @Test
    @Order(4)
    void delete() {
        boolean deleted = employeeService.delete(employee2.getEmployeeId());
        assertNotNull(deleted);
        System.out.println("Deleted: " + employee2.getEmployeeId());
    }

    @Test
    @Order(5)
    void getAll() {
        System.out.println(employeeService.getAll());
    }


    @Test
    @Order(6)
    void findEmployeeByLastName() {
        List<Employee> employeeList = employeeService.findEmployeeByLastName(employee3.getLastName());
        System.out.println(employeeList);
    }

    @Test
    @Order(7)
    void findEmployeeByLastNameAndSalary() {
        List<Employee> employeeList = employeeService.findEmployeeByLastNameAndSalary(employee1.getLastName(), employee1.getSalary());
        System.out.println(employeeList);
    }

    @Test
    @Order(8)
    void findEmployeeBySalaryOrFirstname() {
        List<Employee> employeeList = employeeService.findEmployeeBySalaryOrFirstname(employee1.getSalary(), employee3.getFirstname());
        System.out.println(employeeList);
    }

    @Test
    @Order(9)
    void findBySalaryGreaterThan() {
        List<Employee> employeeList = employeeService.findBySalaryGreaterThan(100000);
        System.out.println(employeeList);

    }

    @Test
    @Order(10)
    void findTop2ByLastNameOrderBySalaryDesc() {
        List<Employee> employeeList = employeeService.findTop2ByLastNameOrderBySalaryDesc(employee1.getLastName());
        System.out.println(employeeList);
    }
}