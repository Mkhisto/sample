package za.ac.cput.factory;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import za.ac.cput.domain.Employee;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeFactoryTest {

    static Employee employee1;
    static Employee employee2;

    @BeforeEach
    void setUp() {

        employee1 = EmployeeFactory.buildEmployee(45674L, "Pelisa", "Pali", 60000);
        employee2 = EmployeeFactory.buildEmployee(22334L, "Yvvonne", "Mthiyane", 60000);
    }

    @Test
    void buildEmployee() {

        assertNotNull(employee1);
        assertEquals(45674L, employee1.getEmployeeId());
        assertEquals("Pelisa", employee1.getFirstname());
        assertEquals("Pali", employee1.getLastName());
        assertEquals(60000, employee1.getSalary());

        assertNotNull(employee2);
        assertEquals(22334L, employee2.getEmployeeId());
        assertEquals("Yvvonne", employee2.getFirstname());
        assertEquals("Mthiyane", employee2.getLastName());
        assertEquals(60000, employee2.getSalary());

        System.out.println("Employee 1: " + employee1);
        System.out.println("Employee 2: " + employee2);


    }
}