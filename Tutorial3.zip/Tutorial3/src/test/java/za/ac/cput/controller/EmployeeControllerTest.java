package za.ac.cput.controller;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import za.ac.cput.domain.Employee;
import za.ac.cput.factory.EmployeeFactory;
import za.ac.cput.service.EmployeeService;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(MethodOrderer.class)
class EmployeeControllerTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    EmployeeService employeeService;

    static Employee employee1;
    static Employee employee2;

    String base_url = "http://localhost:8080/employee/Employee";

    @BeforeAll
    static void setUp() {
        employee1 = EmployeeFactory.buildEmployee(22334L, "Yvvonne", "Mthiyane", 6000);
        employee2 = EmployeeFactory.buildEmployee(45674L, "Pelisa", "Pali", 4000);

        System.out.println(employee1);
        System.out.println(employee2);
    }

    @Test
    void create() {
        String url = base_url + "/create";
        ResponseEntity<Employee> postResponse = restTemplate.postForEntity(url, employee1, Employee.class);
        assertNotNull(postResponse);
        assertNotNull(postResponse.getBody());
        System.out.println(postResponse.getBody());

    }

    @Test
    void read() {
        String url = base_url + "/read" + "/" + employee1.getEmployeeId();
        ResponseEntity<Employee> postResponse = restTemplate.getForEntity(url, Employee.class);
        assertNotNull(postResponse);
        assertNotNull(postResponse.getBody());
        System.out.println(postResponse.getBody());
    }

    @Test
    void update() {
        String url = base_url + "/update";
        Employee updatedEmployee = new Employee.Builder().copy(employee1)
                .setFirstname("Thina")
                .build();

        ResponseEntity<Employee> postResponse = restTemplate.postForEntity(url, updatedEmployee, Employee.class);
        assertNotNull(postResponse);
        assertNotNull(postResponse.getBody());
        System.out.println(postResponse.getBody());
    }

    @Test
    void delete() {
        String url = base_url + "/delete" + employee1.getEmployeeId();
        restTemplate.delete(url);
    }

    @Test
    void getAll() {
        String url = base_url + "/getAll";
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<String> entity = new HttpEntity<>(null, headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        System.out.println("SHOW ALL:");
        System.out.println(response);
    }
}