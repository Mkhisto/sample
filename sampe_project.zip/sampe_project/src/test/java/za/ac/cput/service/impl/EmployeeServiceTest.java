package za.ac.cput.service.impl;

import org.junit.jupiter.api.*;
import za.ac.cput.domain.Department;
import za.ac.cput.domain.Employee;
import za.ac.cput.factory.DepartmentFactory;
import za.ac.cput.factory.EmployeeFactory;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class EmployeeServiceTest {

    private  EmployeeService service = EmployeeService.getService();
    private  Department dept = DepartmentFactory.createDepartment("D01", "Finance");
    private  Employee employee = EmployeeFactory.createEmployee("E01", "Alice", dept);

    @Test
    @Order(1)
    void create() {
        assertNotNull(service.create(employee));
    }

    @Test
    @Order(2)
    void read() {
        assertEquals("E01", service.read("E01").getId());
    }

    @Test
    @Order(3)
    void update() {
        Employee updated = new Employee.Builder().copy(employee).setName("Alicia").build();
        assertEquals("Alicia", service.update(updated).getName());
    }

    @Test
    @Order(4)
    void delete() {
        assertTrue(service.delete("E01"));
    }

    @Test
    @Order(5)
    void getAll() {
        assertFalse(service.getAll().isEmpty());
    }
}
