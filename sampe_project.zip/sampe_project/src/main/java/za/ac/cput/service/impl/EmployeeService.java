package za.ac.cput.service.impl;

import za.ac.cput.domain.Employee;
import za.ac.cput.repository.impl.EmployeeRepository;
import za.ac.cput.service.IEmployeeService;
import java.util.Set;

public class EmployeeService  implements IEmployeeService {
    private static EmployeeService service = null;
    private final EmployeeRepository repository = EmployeeRepository.getRepository();

    private EmployeeService() {}

    public static EmployeeService getService() {
        if (service == null) service = new EmployeeService();
        return service;
    }

    public Employee create(Employee employee) {
        return repository.create(employee);
    }

    public Employee read(String id) {
        return repository.read(id);
    }

    public Employee update(Employee employee) {
        return repository.update(employee);
    }

    public boolean delete(String id) {
        return repository.delete(id);
    }

    public Set<Employee> getAll() {
        return repository.getAll();
    }
}
