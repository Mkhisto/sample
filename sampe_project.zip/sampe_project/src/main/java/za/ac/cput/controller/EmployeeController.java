package za.ac.cput.controller;

import org.springframework.web.bind.annotation.*;
import za.ac.cput.domain.Department;
import za.ac.cput.domain.Employee;
import za.ac.cput.factory.DepartmentFactory;
import za.ac.cput.factory.EmployeeFactory;
import za.ac.cput.service.impl.EmployeeService;

import java.util.Set;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    private final EmployeeService service = EmployeeService.getService();

    @PostMapping("/create")
    public Employee create(@RequestBody Employee employee) {
        return service.create(employee);
    }

    @GetMapping("/read/{id}")
    public Employee read(@PathVariable String id) {
        return service.read(id);
    }

    @PutMapping("/update")
    public Employee update(@RequestBody Employee employee) {
        return service.update(employee);
    }

    @DeleteMapping("/delete/{id}")
    public boolean delete(@PathVariable String id) {
        return service.delete(id);
    }

    @GetMapping("/all")
    public Set<Employee> getAll() {
        return service.getAll();
    }
}
