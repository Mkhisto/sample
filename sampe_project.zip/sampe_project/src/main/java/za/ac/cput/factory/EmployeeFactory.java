package za.ac.cput.factory;

import za.ac.cput.domain.Department;
import za.ac.cput.domain.Employee;
import za.ac.cput.util.Helper;

public class EmployeeFactory {

    public static Employee createEmployee(String id, String name, Department department) {
        if (Helper.isNullOrEmpty(id) || Helper.isNullOrEmpty(name) || department == null)
            return null;

        return new Employee.Builder()
                .setId(id).setName(name).
                setDepartment(department).
                build();
    }
}
