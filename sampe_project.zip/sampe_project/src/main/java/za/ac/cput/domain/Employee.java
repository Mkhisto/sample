package za.ac.cput.domain;

public class Employee {
    private  String id;
    private  String name;
    private  Department department; // Aggregation

    public Employee() {
    }

    private Employee(Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.department = builder.department;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Department getDepartment() {
        return department;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", department=" + department +
                '}';
    }

    public static class Builder {
        private String id;
        private String name;
        private Department department;

        public Builder setId(String id) {
            this.id = id;
            return this;
        }
        public Builder setName(String name) {
            this.name = name;
            return this;
        }
        public Builder setDepartment(Department department) {
            this.department = department;
            return this;
        }

        public Builder copy(Employee employee) {
            this.id = employee.id;
            this.name = employee.name;
            this.department = employee.department;
            return this;
        }

        public Employee build() {
            return new Employee(this);
        }
    }
}
