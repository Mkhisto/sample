package za.ac.cput.factory;

import za.ac.cput.domain.Department;
import za.ac.cput.util.Helper;

public class DepartmentFactory {
    public static Department createDepartment(String id, String name) {
        if (Helper.isNullOrEmpty(id) || Helper.isNullOrEmpty(name))
            return null;

        return new Department.Builder()
                .setDeptId(id)
                .setDeptName(name)
                .build();
    }
}
