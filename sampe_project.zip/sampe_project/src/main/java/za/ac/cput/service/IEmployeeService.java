package za.ac.cput.service;

import za.ac.cput.domain.Employee;

import java.util.Set;

public interface IEmployeeService {

    Employee create(Employee employee);
    Employee read(String id);
    Employee update(Employee employee);
    boolean delete(String id);
    Set<Employee> getAll();
}
