package za.ac.cput.repository.impl;

import java.util.*;
import za.ac.cput.domain.Employee;
import za.ac.cput.repository.IEmployeeRepository;

public class EmployeeRepository implements IEmployeeRepository{
    private static EmployeeRepository repository = null;
    private final Set<Employee> employeeSet = new HashSet<>();

    private EmployeeRepository() {}

    public static EmployeeRepository getRepository() {
        if (repository == null) repository = new EmployeeRepository();
        return repository;
    }

    public Employee create(Employee employee) {
        employeeSet.add(employee);
        return employee;
    }

    @Override
    public Employee create(Employee employee) {
        return null;
    }

    public Employee read(String id) {
        return employeeSet.stream().filter(e -> e.getId().equals(id)).findFirst().orElse(null);
    }

    public Employee update(Employee employee) {
        Employee old = read(employee.getId());
        if (old != null) {
            employeeSet.remove(old);
            employeeSet.add(employee);
            return employee;
        }
        return null;
    }

    public boolean delete(String id) {
        Employee e = read(id);
        if (e == null) return false;
        employeeSet.remove(e);
        return true;
    }

    public Set<Employee> getAll() { return employeeSet; }
}
