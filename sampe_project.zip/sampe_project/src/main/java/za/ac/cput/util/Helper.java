package za.ac.cput.util;

public class Helper {
    public static boolean isNullOrEmpty(String value) {
        return value == null || value.isEmpty();
    }
}
