package za.ac.cput.domain;

public class Department {
    private  String deptId;
    private  String deptName;

    public Department() {
    }

    private Department(Builder builder) {
        this.deptId = builder.deptId;
        this.deptName = builder.deptName;
    }

    public String getDeptId() {
        return deptId;
    }
    public String getDeptName() {
        return deptName;
    }

    public static class Builder {
        private String deptId;
        private String deptName;

        public Builder setDeptId(String deptId) {
            this.deptId = deptId;
            return this;
        }
        public Builder setDeptName(String deptName) {
            this.deptName = deptName;
            return this;
        }

        public Builder copy(Department department) {
            this.deptId = department.deptId;
            this.deptName = department.deptName;
            return this;
        }

        public Department build() {
            return new Department(this);
        }
    }
}

